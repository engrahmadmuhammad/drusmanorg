<?php
declare(strict_types=1);

function load_env_file(string $path): void {
    if (!is_file($path)) return;
    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) ?: [] as $line) {
        $line = trim($line);
        if ($line === '' || str_starts_with($line, '#') || !str_contains($line, '=')) continue;
        [$key, $value] = explode('=', $line, 2);
        $key = trim($key);
        $value = trim($value);
        if ($key !== '' && getenv($key) === false) putenv($key . '=' . $value);
    }
}

function env(string $key, string $default = ''): string {
    $value = getenv($key);
    return $value === false ? $default : (string)$value;
}

function text_length(string $value): int {
    return function_exists('mb_strlen') ? mb_strlen($value) : strlen($value);
}

function app_config(): array {
    static $config;
    if ($config !== null) return $config;
    load_env_file(dirname(__DIR__) . '/.env');
    date_default_timezone_set(env('APP_TIMEZONE', 'Africa/Lagos'));
    $config = [
        'app_url' => rtrim(env('APP_URL'), '/'),
'db_host' => env('DB_HOST', 'localhost'),
        'db_port' => env('DB_PORT', '3306'),
        'db_name' => env('DB_NAME'),
        'db_user' => env('DB_USER'),
        'db_pass' => env('DB_PASS'),
        'db_charset' => env('DB_CHARSET', 'utf8mb4'),
        'mail_from' => env('MAIL_FROM'),
        'mail_from_name' => env('MAIL_FROM_NAME', 'Appointments'),
        'mail_reply_to' => env('MAIL_REPLY_TO'),
        'clinic_phone' => env('CLINIC_PHONE'),
        'whatsapp_number' => preg_replace('/\D+/', '', env('WHATSAPP_NUMBER')),
        // Optional WhatsApp Business click-to-chat link (e.g. wa.me/message/VEALYDXXF4PDF1).
        // When set, public pages and confirmation links prefer this over a plain number link.
        'whatsapp_click_link' => env('WHATSAPP_CLICK_LINK'),
        'sms_enabled' => filter_var(env('SMS_ENABLED', 'false'), FILTER_VALIDATE_BOOL),
        // Payment (Paystack)
        'paystack_public_key' => env('PAYSTACK_PUBLIC_KEY'),
        'paystack_secret_key' => env('PAYSTACK_SECRET_KEY'),
        'paystack_webhook_secret' => env('PAYSTACK_WEBHOOK_SECRET'),
        'paystack_currency' => env('PAYSTACK_CURRENCY', 'NGN'),
        // SMS / WhatsApp provider credentials.
        // Leave a provider blank to disable it and fall back to email + WhatsApp link.
        // SMS_PROVIDER selects the active SMS gateway: 'termii' or 'twilio'.
        'sms_provider' => env('SMS_PROVIDER'),
        // Termii credentials (https://termii.com)
        'termii_api_key' => env('TERMII_API_KEY'),
        'termii_sender' => env('TERMII_SENDER'),
        // Twilio credentials (https://twilio.com)
        'twilio_account_sid' => env('TWILIO_ACCOUNT_SID'),
        'twilio_auth_token' => env('TWILIO_AUTH_TOKEN'),
        'twilio_from' => env('TWILIO_FROM'),
        // WhatsApp Business Cloud API (Meta) credentials (https://developers.facebook.com/docs/whatsapp/cloud-api)
        'whatsapp_phone_number_id' => env('WHATSAPP_PHONE_NUMBER_ID'),
        'whatsapp_access_token' => env('WHATSAPP_ACCESS_TOKEN'),
        'whatsapp_business_account_id' => env('WHATSAPP_BUSINESS_ACCOUNT_ID'),
        // Reminder window (hours before appointment) and deposit mode.
        'reminder_hours' => env('REMINDER_HOURS', '24'),
        'deposit_mode' => env('DEPOSIT_MODE', 'none'), // server fallback; per-service amounts preferred
    ];
    return $config;
}

function json_response(array $payload, int $status = 200): never {
    http_response_code($status);
    header('Content-Type: application/json; charset=utf-8');
    header('X-Content-Type-Options: nosniff');
    echo json_encode($payload, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    exit;
}

function request_json(): array {
    $data = json_decode((string) file_get_contents('php://input'), true);
    return is_array($data) ? $data : [];
}
