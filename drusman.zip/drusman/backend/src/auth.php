<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

function start_staff_session(): void {
    if (session_status() === PHP_SESSION_ACTIVE) return;
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') || (($_SERVER['SERVER_PORT'] ?? '') === '443');
    session_name('umb_staff');
    session_set_cookie_params(['lifetime' => 0, 'path' => '/', 'secure' => $https, 'httponly' => true, 'samesite' => 'Strict']);
    session_start();
}

function staff_user(): ?array { start_staff_session(); return $_SESSION['staff'] ?? null; }
function staff_require(array $roles = []): array {
    $user = staff_user();
    if (!$user || (!$roles ? false : !in_array($user['role'], $roles, true))) json_response(['error' => 'Unauthorized.'], 401);
    return $user;
}
function csrf_token(): string { start_staff_session(); return $_SESSION['csrf'] ??= bin2hex(random_bytes(32)); }
function csrf_require(): void {
    start_staff_session();
    $token = (string) ($_SERVER['HTTP_X_CSRF_TOKEN'] ?? '');
    if (!$token || !hash_equals((string) ($_SESSION['csrf'] ?? ''), $token)) json_response(['error' => 'Invalid security token.'], 403);
}
function staff_login(PDO $pdo, string $email, string $password): array|false {
    $stmt = $pdo->prepare('SELECT id, name, email, password_hash, role FROM staff_users WHERE email = ? AND active = 1 LIMIT 1');
    $stmt->execute([strtolower(trim($email))]); $row = $stmt->fetch();
    if (!$row || !password_verify($password, $row['password_hash'])) return false;
    if (password_needs_rehash($row['password_hash'], PASSWORD_DEFAULT)) $pdo->prepare('UPDATE staff_users SET password_hash = ? WHERE id = ?')->execute([password_hash($password, PASSWORD_DEFAULT), $row['id']]);
    start_staff_session(); session_regenerate_id(true);
    $_SESSION['staff'] = ['id' => (int)$row['id'], 'name' => $row['name'], 'email' => $row['email'], 'role' => $row['role']];
    $_SESSION['csrf'] = bin2hex(random_bytes(32));
    return $_SESSION['staff'];
}
function require_strong_password(string $password): void {
    if (text_length($password) < 12 || !preg_match('/[a-z]/', $password) || !preg_match('/[A-Z]/', $password) || !preg_match('/\d/', $password) || !preg_match('/[^a-zA-Z\d]/', $password)) {
        json_response(['error' => 'Use a password with at least 12 characters, including upper- and lower-case letters, a number, and a symbol.'], 422);
    }
}
function audit(PDO $pdo, int $staffId, string $action, string $entity, ?int $entityId = null): void {
    $pdo->prepare('INSERT INTO audit_logs (staff_user_id, action, entity, entity_id, ip_address) VALUES (?, ?, ?, ?, ?)')->execute([$staffId, $action, $entity, $entityId, $_SERVER['REMOTE_ADDR'] ?? null]);
}
