<?php
declare(strict_types=1);
require_once __DIR__ . '/auth.php';

function staff_appointment(PDO $pdo, int $id): ?array {
    $q = $pdo->prepare('SELECT a.*, l.name location_name, s.name service_name FROM appointments a JOIN locations l ON l.id=a.location_id JOIN services s ON s.id=a.service_id WHERE a.id=?'); $q->execute([$id]); return $q->fetch() ?: null;
}
function staff_config(PDO $pdo): array {
    return [
        'locations' => $pdo->query('SELECT * FROM locations ORDER BY name')->fetchAll(),
        'services' => $pdo->query('SELECT * FROM services ORDER BY name')->fetchAll(),
        'availability' => $pdo->query('SELECT r.*, l.name location_name FROM availability_rules r JOIN locations l ON l.id=r.location_id ORDER BY l.name, weekday, starts_at')->fetchAll(),
        'blocks' => $pdo->query('SELECT b.*, l.name location_name FROM blocked_slots b JOIN locations l ON l.id=b.location_id ORDER BY starts_at DESC LIMIT 100')->fetchAll(),
    ];
}
function staff_config_save(PDO $pdo, array $input, array $user): void {
    $entity = (string)($input['entity'] ?? ''); $action = (string)($input['action'] ?? 'save'); $id = filter_var($input['id'] ?? null, FILTER_VALIDATE_INT);
    if ($action === 'toggle' && in_array($entity,['location','service'],true) && $id) {
        $table = $entity === 'location' ? 'locations' : 'services';
        $pdo->prepare("UPDATE {$table} SET active = NOT active WHERE id = ?")->execute([$id]);
    } elseif ($action === 'delete' && in_array($entity,['availability','block'],true) && $id) {
        $table=$entity === 'availability' ? 'availability_rules' : 'blocked_slots'; $pdo->prepare("DELETE FROM {$table} WHERE id=?")->execute([$id]);
    } elseif ($entity === 'location') {
        $name = required_string($input, 'name', 2, 160); $address = required_string($input, 'address', 2, 255); $phone = trim((string)($input['phone'] ?? '')); $active = filter_var($input['active'] ?? true, FILTER_VALIDATE_BOOL) ? 1 : 0;
        if ($id) $pdo->prepare('UPDATE locations SET name=?,address=?,phone=?,active=? WHERE id=?')->execute([$name,$address,$phone ?: null,$active,$id]);
        else { $pdo->prepare('INSERT INTO locations (name,address,phone,active) VALUES (?,?,?,?)')->execute([$name,$address,$phone ?: null,$active]); $id=(int)$pdo->lastInsertId(); }
} elseif ($entity === 'service') {
        $name=required_string($input,'name',2,160); $description=trim((string)($input['description']??'')); $duration=filter_var($input['duration_minutes']??null,FILTER_VALIDATE_INT); $price=trim((string)($input['price_ngn']??'')); $deposit=trim((string)($input['deposit_amount_ngn']??'')); $active=filter_var($input['active']??true,FILTER_VALIDATE_BOOL)?1:0;
        if (!$duration || $duration < 5 || $duration > 480 || ($price !== '' && (!is_numeric($price) || (float)$price < 0)) || ($deposit !== '' && (!is_numeric($deposit) || (float)$deposit < 0))) json_response(['error'=>'Invalid service duration, price, or deposit.'],422);
        if ($id) $pdo->prepare('UPDATE services SET name=?,description=?,duration_minutes=?,price_ngn=?,deposit_amount_ngn=?,active=? WHERE id=?')->execute([$name,$description ?: null,$duration,$price === '' ? null : $price,$deposit === '' ? null : $deposit,$active,$id]);
        else { $pdo->prepare('INSERT INTO services (name,description,duration_minutes,price_ngn,deposit_amount_ngn,active) VALUES (?,?,?,?,?,?)')->execute([$name,$description ?: null,$duration,$price === '' ? null : $price,$deposit === '' ? null : $deposit,$active]); $id=(int)$pdo->lastInsertId(); }
    } elseif ($entity === 'availability') {
        $location=filter_var($input['location_id']??null,FILTER_VALIDATE_INT); $weekday=filter_var($input['weekday']??null,FILTER_VALIDATE_INT); $start=required_string($input,'starts_at',5,8); $end=required_string($input,'ends_at',5,8); $minutes=filter_var($input['slot_minutes']??null,FILTER_VALIDATE_INT); $active=filter_var($input['active']??true,FILTER_VALIDATE_BOOL)?1:0;
        if (!$location || !$weekday || $weekday > 7 || !$minutes || $minutes < 5 || $minutes > 120 || $end <= $start) json_response(['error'=>'Invalid availability rule.'],422);
        if ($id) $pdo->prepare('UPDATE availability_rules SET location_id=?,weekday=?,starts_at=?,ends_at=?,slot_minutes=?,active=? WHERE id=?')->execute([$location,$weekday,$start,$end,$minutes,$active,$id]);
        else { $pdo->prepare('INSERT INTO availability_rules (location_id,weekday,starts_at,ends_at,slot_minutes,active) VALUES (?,?,?,?,?,?)')->execute([$location,$weekday,$start,$end,$minutes,$active]); $id=(int)$pdo->lastInsertId(); }
    } elseif ($entity === 'block') {
        $location=filter_var($input['location_id']??null,FILTER_VALIDATE_INT); $start=required_string($input,'starts_at',16,19); $end=required_string($input,'ends_at',16,19); $reason=trim((string)($input['reason']??''));
        if (!$location || $end <= $start) json_response(['error'=>'Invalid blocked time.'],422);
        if ($id) $pdo->prepare('UPDATE blocked_slots SET location_id=?,starts_at=?,ends_at=?,reason=? WHERE id=?')->execute([$location,$start,$end,$reason ?: null,$id]);
        else { $pdo->prepare('INSERT INTO blocked_slots (location_id,starts_at,ends_at,reason) VALUES (?,?,?,?)')->execute([$location,$start,$end,$reason ?: null]); $id=(int)$pdo->lastInsertId(); }
    } else json_response(['error'=>'Unsupported configuration action.'],422);
    audit($pdo,$user['id'],'save',$entity,$id ?: null); json_response(['ok'=>true]);
}
function dispatch_staff_route(PDO $pdo, string $method, string $route): bool {
    if (!str_starts_with($route, 'staff/')) return false;
    $input = $method === 'GET' ? $_GET : request_json();
    if ($route === 'staff/bootstrap' && $method === 'POST') {
        if ((int)$pdo->query('SELECT COUNT(*) FROM staff_users')->fetchColumn() > 0) json_response(['error'=>'A staff account already exists.'],403);
        $setupToken = env('SETUP_ADMIN_TOKEN');
        if (text_length($setupToken) < 32 || !hash_equals($setupToken, (string)($_SERVER['HTTP_X_SETUP_TOKEN'] ?? ''))) json_response(['error'=>'Invalid setup token.'],403);
        $name=required_string($input,'name',2,160); $email=required_string($input,'email',5,190); $password=required_string($input,'password',12,255);
        if (!filter_var($email,FILTER_VALIDATE_EMAIL)) json_response(['error'=>'Invalid email address.'],422); require_strong_password($password);
        $pdo->prepare("INSERT INTO staff_users (name,email,password_hash,role) VALUES (?,?,?,'admin')")->execute([$name,strtolower($email),password_hash($password,PASSWORD_DEFAULT)]);
        json_response(['ok'=>true]);
    }
    if ($route === 'staff/login' && $method === 'POST') {
        start_staff_session(); $now=time(); if (($_SESSION['login_block_until']??0)>$now) json_response(['error'=>'Too many failed attempts. Try again later.'],429);
        $user=staff_login($pdo,required_string($input,'email',5,190),required_string($input,'password',1,255));
        if (!$user) { $_SESSION['login_failures']=($_SESSION['login_failures']??0)+1; if ($_SESSION['login_failures']>=5) $_SESSION['login_block_until']=$now+900; json_response(['error'=>'Invalid email or password.'],401); }
        unset($_SESSION['login_failures'],$_SESSION['login_block_until']); audit($pdo,$user['id'],'login','staff_user',$user['id']); json_response(['staff'=>$user,'csrf_token'=>csrf_token()]);
    }
    if ($route === 'staff/logout' && $method === 'POST') { $user=staff_require(['admin','scheduler','clinician']); csrf_require(); audit($pdo,$user['id'],'logout','staff_user',$user['id']); $_SESSION=[]; session_destroy(); json_response(['ok'=>true]); }
    if ($route === 'staff/me' && $method === 'GET') { $user=staff_user(); json_response(['staff'=>$user,'csrf_token'=>$user?csrf_token():null]); }
if ($route === 'staff/appointments' && $method === 'GET') {
        staff_require(['admin','scheduler','clinician']); $date=(string)($input['date']??date('Y-m-d')); $status=(string)($input['status']??'');
        $sql='SELECT a.*,l.name location_name,s.name service_name FROM appointments a JOIN locations l ON l.id=a.location_id JOIN services s ON s.id=a.service_id WHERE DATE(a.appointment_at)=?'; $args=[$date]; if ($status !== '') {$sql.=' AND a.status=?';$args[]=$status;} $sql.=' ORDER BY a.appointment_at'; $q=$pdo->prepare($sql);$q->execute($args);
        $appointments=$q->fetchAll();
        // Attach the latest payment status to each appointment row.
        foreach ($appointments as &$appt) {
            $payment=payment_for_appointment($pdo,(int)$appt['id']);
            $appt['payment_status']= $payment ? $payment['status'] : null;
            $appt['payment_amount']= $payment ? $payment['amount_ngn'] : null;
            $appt['payment_reference']= $payment ? $payment['reference'] : null;
        } unset($appt);
        json_response(['appointments'=>$appointments]);
    }
    if ($route === 'staff/payments' && $method === 'GET') {
        staff_require(['admin']); $date=(string)($input['date']??date('Y-m-d'));
        $sql='SELECT p.*,a.booking_code,a.patient_name,a.appointment_at,s.name service_name FROM payments p JOIN appointments a ON a.id=p.appointment_id JOIN services s ON s.id=a.service_id WHERE DATE(p.created_at)=? ORDER BY p.created_at DESC'; $q=$pdo->prepare($sql);$q->execute([$date]);json_response(['payments'=>$q->fetchAll()]);
    }
    if ($route === 'staff/appointment/status' && $method === 'POST') {
        $user=staff_require(['admin','scheduler','clinician']); csrf_require(); $id=filter_var($input['id']??null,FILTER_VALIDATE_INT);$status=(string)($input['status']??''); if(!$id||!in_array($status,['pending','confirmed','cancelled','completed','no_show'],true))json_response(['error'=>'Invalid appointment status.'],422); $pdo->prepare('UPDATE appointments SET status=?,cancelled_at=IF(?=\'cancelled\',NOW(),cancelled_at) WHERE id=?')->execute([$status,$status,$id]);audit($pdo,$user['id'],'set_status','appointment',$id);json_response(['ok'=>true]);
    }
    if ($route === 'staff/appointment/reschedule' && $method === 'POST') {
        $user=staff_require(['admin','scheduler']); csrf_require(); $id=filter_var($input['id']??null,FILTER_VALIDATE_INT); $date=required_string($input,'date',10,10); $time=required_string($input,'time',5,5); $appointment=$id?staff_appointment($pdo,$id):null;
        $start=DateTimeImmutable::createFromFormat('!Y-m-d H:i',"$date $time"); if(!$appointment||!$start||$start->format('Y-m-d H:i')!=="$date $time")json_response(['error'=>'Invalid appointment or time.'],422);
        $pdo->beginTransaction();$slot=valid_slot($pdo,(int)$appointment['location_id'],(int)$appointment['service_id'],$start,$id);if(!$slot){$pdo->rollBack();json_response(['error'=>'That slot is not available.'],409);} $pdo->prepare("UPDATE appointments SET appointment_at=?,duration_minutes=?,status='pending' WHERE id=?")->execute([$start->format('Y-m-d H:i:s'),$slot['duration'],$id]);$pdo->commit();$updated=staff_appointment($pdo,$id);$updated['manage_token']=$appointment['manage_token'];send_appointment_email($updated,'rescheduled by the clinic');audit($pdo,$user['id'],'reschedule','appointment',$id);json_response(['ok'=>true]);
    }
    if ($route === 'staff/config' && $method === 'GET') { staff_require(['admin']); json_response(staff_config($pdo)); }
    if ($route === 'staff/config/save' && $method === 'POST') { $user=staff_require(['admin']); csrf_require(); staff_config_save($pdo,$input,$user); }
    if ($route === 'staff/users' && $method === 'GET') { staff_require(['admin']); json_response(['users'=>$pdo->query('SELECT id,name,email,role,active,created_at FROM staff_users ORDER BY name')->fetchAll()]); }
    if ($route === 'staff/users' && $method === 'POST') { $user=staff_require(['admin']);csrf_require();$name=required_string($input,'name',2,160);$email=required_string($input,'email',5,190);$password=required_string($input,'password',12,255);$role=(string)($input['role']??'');if(!filter_var($email,FILTER_VALIDATE_EMAIL)||!in_array($role,['admin','scheduler','clinician'],true))json_response(['error'=>'Invalid staff account details.'],422);require_strong_password($password);$pdo->prepare('INSERT INTO staff_users (name,email,password_hash,role) VALUES (?,?,?,?)')->execute([$name,strtolower($email),password_hash($password,PASSWORD_DEFAULT),$role]);$id=(int)$pdo->lastInsertId();audit($pdo,$user['id'],'create','staff_user',$id);json_response(['ok'=>true]); }
    if ($route === 'staff/content/videos' && $method === 'GET') { staff_require(['admin']); json_response(['videos'=>$pdo->query('SELECT * FROM content_videos ORDER BY sort_order, created_at DESC')->fetchAll()]); }
    if ($route === 'staff/content/videos' && $method === 'POST') { $user=staff_require(['admin']);csrf_require();$id=filter_var($input['id']??null,FILTER_VALIDATE_INT);$title=required_string($input,'title',2,180);$subtitle=trim((string)($input['subtitle']??''));$url=required_string($input,'youtube_url',6,255);$duration=trim((string)($input['duration_label']??''));$featured=filter_var($input['featured']??false,FILTER_VALIDATE_BOOL)?1:0;$published=filter_var($input['published']??false,FILTER_VALIDATE_BOOL)?1:0;$order=filter_var($input['sort_order']??0,FILTER_VALIDATE_INT);if(!preg_match('#^(https?://)?(www\.)?(youtube\.com|youtu\.be)/#i',$url))json_response(['error'=>'Enter a valid YouTube URL.'],422);if($id)$pdo->prepare('UPDATE content_videos SET title=?,subtitle=?,youtube_url=?,duration_label=?,featured=?,published=?,sort_order=? WHERE id=?')->execute([$title,$subtitle?:null,$url,$duration?:null,$featured,$published,$order?:0,$id]);else{$pdo->prepare('INSERT INTO content_videos (title,subtitle,youtube_url,duration_label,featured,published,sort_order) VALUES (?,?,?,?,?,?,?)')->execute([$title,$subtitle?:null,$url,$duration?:null,$featured,$published,$order?:0]);$id=(int)$pdo->lastInsertId();}audit($pdo,$user['id'],'save','content_video',$id);json_response(['ok'=>true]); }
    if ($route === 'staff/content/videos/delete' && $method === 'POST') { $user=staff_require(['admin']);csrf_require();$id=filter_var($input['id']??null,FILTER_VALIDATE_INT);if(!$id)json_response(['error'=>'Invalid video.'],422);$pdo->prepare('DELETE FROM content_videos WHERE id=?')->execute([$id]);audit($pdo,$user['id'],'delete','content_video',$id);json_response(['ok'=>true]); }
    if ($route === 'staff/contact/messages' && $method === 'GET') { staff_require(['admin','scheduler','clinician']); json_response(['messages'=>$pdo->query('SELECT * FROM contact_messages ORDER BY created_at DESC')->fetchAll()]); }
    if ($route === 'staff/contact/messages/status' && $method === 'POST') { $user=staff_require(['admin','scheduler']);csrf_require();$id=filter_var($input['id']??null,FILTER_VALIDATE_INT);$status=(string)($input['status']??'');if(!$id||!in_array($status,['new','read','replied'],true))json_response(['error'=>'Invalid message status.'],422);$pdo->prepare('UPDATE contact_messages SET status=? WHERE id=?')->execute([$status,$id]);audit($pdo,$user['id'],'set_status','contact_message',$id);json_response(['ok'=>true]); }
    json_response(['error'=>'Staff route not found.'],404);
}
