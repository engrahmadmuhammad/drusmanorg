<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/db.php';

/**
 * Deposit / payment helpers.
 *
 * IMPORTANT SECURITY RULE:
 * A payment is NEVER marked 'paid' based on a browser redirect or any
 * client-supplied callback. It is only marked 'paid' after a server-to-server
 * verification against the gateway (Paystack verify API) or after a signed
 * webhook is received from the gateway.
 */

/** Amount is always computed server-side from the service deposit. */
function appointment_deposit_amount(PDO $pdo, array $appointment): ?string {
    $stmt = $pdo->prepare('SELECT deposit_amount_ngn FROM services WHERE id = ?');
    $stmt->execute([$appointment['service_id']]);
    $deposit = $stmt->fetchColumn();
    if ($deposit === false || $deposit === null || (float) $deposit <= 0) return null;
    return number_format((float) $deposit, 2, '.', '');
}

/** Fetch the newest payment row for an appointment. */
function payment_for_appointment(PDO $pdo, int $appointmentId): ?array {
    $stmt = $pdo->prepare('SELECT * FROM payments WHERE appointment_id = ? ORDER BY id DESC LIMIT 1');
    $stmt->execute([$appointmentId]);
    return $stmt->fetch() ?: null;
}

/** Idempotent insert/update of a payment row. */
function record_payment(PDO $pdo, array $data): int {
    $appointmentId = (int) ($data['appointment_id'] ?? 0);
    $reference = (string) ($data['reference'] ?? '');
    $provider = (string) ($data['provider'] ?? 'paystack');
    $amount = (string) ($data['amount_ngn'] ?? '0');
    $currency = (string) ($data['currency'] ?? 'NGN');
    $status = (string) ($data['status'] ?? 'pending');
    $gatewayResponse = $data['gateway_response'] ?? null;
    $metadata = $data['metadata'] ?? null;
    $verifiedAt = $data['verified_at'] ?? null;

    $existing = $pdo->prepare('SELECT id FROM payments WHERE reference = ? LIMIT 1');
    $existing->execute([$reference]);
    $id = $existing->fetchColumn();
    if ($id) {
        $pdo->prepare(
            'UPDATE payments SET status = ?, gateway_response = ?, metadata = ?, verified_at = COALESCE(?, verified_at) WHERE id = ?'
        )->execute([$status, $gatewayResponse, $metadata, $verifiedAt, (int) $id]);
        return (int) $id;
    }
    $pdo->prepare(
        'INSERT INTO payments (appointment_id, reference, provider, amount_ngn, currency, status, gateway_response, metadata, verified_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)'
    )->execute([$appointmentId, $reference, $provider, $amount, $currency, $status, $gatewayResponse, $metadata, $verifiedAt]);
    return (int) $pdo->lastInsertId();
}

/** Low-level HTTPS request helper. Returns decoded JSON or null on failure. */
function gateway_http_request(string $method, string $url, array $headers, ?string $body = null): ?array {
    $opts = [
        'http' => [
            'method' => $method,
            'header' => implode("\r\n", $headers) . "\r\n",
            'ignore_errors' => true,
            'timeout' => 20,
        ],
    ];
    if ($body !== null) $opts['http']['content'] = $body;
    $context = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $context);
    if ($raw === false) return null;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : null;
}

/**
 * Initialize a Paystack transaction server-side.
 * Returns ['ok'=>true,'authorization_url'=>..,'reference'=>..] or throws.
 */
function paystack_initialize(PDO $pdo, array $appointment, string $amount, string $email, string $callbackUrl): array {
    $cfg = app_config();
    if ($cfg['paystack_secret_key'] === '') throw new RuntimeException('Payment is not configured.');
    $reference = 'UMB-' . strtoupper(bin2hex(random_bytes(8)));
    record_payment($pdo, [
        'appointment_id' => $appointment['id'],
        'reference'      => $reference,
        'provider'       => 'paystack',
        'amount_ngn'     => $amount,
        'currency'       => $cfg['paystack_currency'] ?: 'NGN',
        'status'         => 'pending',
    ]);
    $body = json_encode([
        'email'           => $email,
        'amount'          => (int) round(((float) $amount) * 100), // kobo
        'currency'        => $cfg['paystack_currency'] ?: 'NGN',
        'reference'       => $reference,
        'callback_url'    => $callbackUrl,
        'metadata'        => ['appointment_id' => $appointment['id'], 'booking_code' => $appointment['booking_code']],
    ]);
    $resp = gateway_http_request(
        'POST',
        'https://api.paystack.co/transaction/initialize',
        ['Authorization: Bearer ' . $cfg['paystack_secret_key'], 'Content-Type: application/json'],
        $body
    );
    if (!$resp || empty($resp['status']) || empty($resp['data']['authorization_url'])) {
        throw new RuntimeException($resp['message'] ?? 'Unable to start payment. Please contact the clinic.');
    }
    return [
        'ok' => true,
        'authorization_url' => $resp['data']['authorization_url'],
        'reference'         => $reference,
    ];
}

/**
 * Server-to-server verification of a Paystack transaction.
 * Only marks the payment 'paid' when the gateway confirms success.
 */
function paystack_verify(PDO $pdo, string $reference, ?string $appointmentId = null): array {
    $cfg = app_config();
    if ($cfg['paystack_secret_key'] === '') throw new RuntimeException('Payment verification is not configured.');
    $resp = gateway_http_request(
        'GET',
        'https://api.paystack.co/transaction/verify/' . rawurlencode($reference),
        ['Authorization: Bearer ' . $cfg['paystack_secret_key']]
    );
    if (!$resp || empty($resp['status'])) throw new RuntimeException('Unable to verify payment. Please try again or contact the clinic.');
    $data = $resp['data'] ?? [];
$gatewayStatus = (string) ($data['status'] ?? '');
    $paid = $gatewayStatus === 'success';
    $status = $paid ? 'paid' : 'failed';

    // Find the appointment id from our ledger if not provided.
    if ($appointmentId === null) {
        $stmt = $pdo->prepare('SELECT appointment_id FROM payments WHERE reference = ? LIMIT 1');
        $stmt->execute([$reference]);
        $appointmentId = $stmt->fetchColumn();
    }
    $amount = (string) ($data['amount'] ?? 0);
    if (is_numeric($amount)) $amount = number_format(((float) $amount) / 100, 2, '.', '');

    record_payment($pdo, [
        'appointment_id'   => $appointmentId !== null ? (int) $appointmentId : 0,
        'reference'        => $reference,
        'gateway_response' => json_encode($data, JSON_UNESCAPED_SLASHES),
        'status'           => $status,
        'verified_at'      => $paid ? date('Y-m-d H:i:s') : null,
    ]);
    return ['ok' => $paid, 'status' => $status, 'reference' => $reference];
}

/**
 * Handle a Paystack webhook. Verifies the signature using the configured
 * secret key, then marks the payment paid/failed from the gateway event.
 */
function handle_paystack_webhook(PDO $pdo, string $rawBody, string $signature): bool {
    $cfg = app_config();
    if ($cfg['paystack_secret_key'] === '') return false;
    $expected = hash_hmac('sha512', $rawBody, $cfg['paystack_secret_key']);
    if (!hash_equals($expected, $signature)) return false;
    $payload = json_decode($rawBody, true);
    if (!is_array($payload)) return false;
    $event = (string) ($payload['event'] ?? '');
    $data = $payload['data'] ?? [];
    $reference = (string) ($data['reference'] ?? '');
    if ($reference === '') return false;
    $statusMap = [
        'charge.success' => 'paid',
        'charge.failed'  => 'failed',
    ];
    $status = $statusMap[$event] ?? null;
    if ($status !== null) {
        // Only the gateway can transition to paid via webhook.
        record_payment($pdo, [
            'reference'        => $reference,
            'status'           => $status,
            'gateway_response' => $rawBody,
            'verified_at'      => $status === 'paid' ? date('Y-m-d H:i:s') : null,
        ]);
    }
    return true;
}
