<?php
declare(strict_types=1);
require_once __DIR__ . '/config.php';

/**
 * Record an outbound notification attempt in the notifications table.
 * Pass a PDO connection (or null to auto-connect). Failure to log is
 * non-fatal and never breaks the booking flow.
 */
function log_notification(PDO $pdo, array $data): void {
    try {
        $stmt = $pdo->prepare(
            'INSERT INTO notifications (appointment_id, channel, recipient, subject, body, status, error, sent_at)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
        );
        $stmt->execute([
            $data['appointment_id'] ?? null,
            $data['channel'] ?? 'email',
            $data['recipient'] ?? '',
            $data['subject'] ?? null,
            $data['body'] ?? null,
            $data['status'] ?? 'sent',
            $data['error'] ?? null,
            $data['sent_at'] ?? null,
        ]);
    } catch (Throwable $e) {
        error_log('Notification log: ' . $e->getMessage());
    }
}

function appointment_manage_url(array $appointment): string {
    $cfg = app_config();
    $base = $cfg['app_url'] !== '' ? $cfg['app_url'] : '';
    return $base . '/front%20end/manage-appointment.html?code=' . rawurlencode($appointment['booking_code']) . '&token=' . rawurlencode($appointment['manage_token']);
}

function send_appointment_email(array $appointment, string $action, ?PDO $pdo = null): bool {
    $cfg = app_config();
    if ($cfg['mail_from'] === '' || !filter_var($appointment['email'], FILTER_VALIDATE_EMAIL)) return false;
    $subject = sprintf('[%s] Appointment %s', $appointment['booking_code'], $action);
    $body = "Hello {$appointment['patient_name']},\n\n" .
        "Your appointment request has been {$action}.\n" .
        "Reference: {$appointment['booking_code']}\n" .
        "Service: {$appointment['service_name']}\n" .
        "Location: {$appointment['location_name']}\n" .
        "Date and time: {$appointment['appointment_at']}\n\n" .
        "Manage, reschedule, or cancel your request: " . appointment_manage_url($appointment) . "\n\n" .
        "This service is not for emergencies. If this is an emergency, seek immediate emergency medical care or call {$cfg['clinic_phone']}.\n";
    $headers = [
        'From: ' . $cfg['mail_from_name'] . ' <' . $cfg['mail_from'] . '>',
        'Reply-To: ' . ($cfg['mail_reply_to'] ?: $cfg['mail_from']),
        'Content-Type: text/plain; charset=UTF-8',
    ];
    $ok = @mail($appointment['email'], $subject, $body, implode("\r\n", $headers));
    if ($pdo) {
        log_notification($pdo, [
            'appointment_id' => $appointment['id'] ?? null,
            'channel'        => 'email',
            'recipient'      => $appointment['email'],
            'subject'        => $subject,
            'body'           => $body,
            'status'         => $ok ? 'sent' : 'failed',
            'error'          => $ok ? null : 'mail() returned false',
            'sent_at'        => $ok ? date('Y-m-d H:i:s') : null,
        ]);
    }
    return $ok;
}

/**
 * Build the WhatsApp confirmation/pre-filled link for an appointment.
 * Prefers the configured WhatsApp Business click-to-chat link when present;
 * otherwise falls back to a wa.me number link with the booking summary.
 */
function whatsapp_confirmation_link(array $appointment): string {
    $cfg = app_config();
    if ($cfg['whatsapp_click_link'] !== '') {
        $link = $cfg['whatsapp_click_link'];
        if (str_starts_with($link, 'https://')) return $link;
        if (str_starts_with($link, 'wa.me/')) return 'https://' . $link;
        return 'https://wa.me/' . ltrim($link, '/');
    }
    if ($cfg['whatsapp_number'] === '') return '';
    $message = "Appointment request {$appointment['booking_code']}%0A" .
        "Service: {$appointment['service_name']}%0A" .
        "Location: {$appointment['location_name']}%0A" .
        "Date: {$appointment['appointment_at']}";
    return 'https://wa.me/' . rawurlencode($cfg['whatsapp_number']) . '?text=' . $message;
}

/** Normalize a phone number to E.164 (+<country><number>). Best effort for Nigerian numbers. */
function normalize_phone_e164(string $phone): string {
    $digits = preg_replace('/[^\d+]/', '', $phone);
    if ($digits === '' || $digits === '0') return '';
    if ($digits[0] === '+') return $digits;
    if (str_starts_with($digits, '234')) return '+' . $digits;
    if (str_starts_with($digits, '0')) return '+234' . substr($digits, 1);
    return '+' . $digits;
}

/** Low-level HTTPS JSON POST helper shared by SMS/WhatsApp providers. */
function notifier_http_post(string $url, array $headers, string $body): ?array {
    $opts = [
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers) . "\r\n",
            'content' => $body,
            'ignore_errors' => true,
            'timeout' => 20,
        ],
    ];
    $context = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $context);
    if ($raw === false) return null;
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : null;
}

/** Compose the short SMS/WhatsApp body for an appointment action. */
function appointment_channel_message(array $appointment, string $action): string {
    return "Appointment {$appointment['booking_code']}: {$action} for {$appointment['appointment_at']}. Service: {$appointment['service_name']}. Location: {$appointment['location_name']}.";
}

/**
 * Send an SMS via the Termii API (https://termii.com).
 * Returns true only when the gateway confirms delivery acceptance.
 */
function send_sms_via_termii(string $to, string $message): bool {
    $cfg = app_config();
    if ($cfg['termii_api_key'] === '' || $cfg['termii_sender'] === '') return false;
    $to = normalize_phone_e164($to);
    if ($to === '') return false;
    $body = json_encode([
        'api_key' => $cfg['termii_api_key'],
        'to'      => $to,
        'from'    => $cfg['termii_sender'],
        'sms'     => $message,
        'type'    => 'plain',
        'channel' => 'generic',
    ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
    $resp = notifier_http_post(
        'https://api.ng.termii.com/api/sms/send',
        ['Content-Type: application/json', 'Accept: application/json'],
        $body
    );
    return is_array($resp) && ($resp['message'] ?? '') === 'Successfully Sent';
}

/**
 * Send an SMS via the Twilio REST API (https://twilio.com).
 * Returns true only when the API returns a queued/sent message SID.
 */
function send_sms_via_twilio(string $to, string $message): bool {
    $cfg = app_config();
    if ($cfg['twilio_account_sid'] === '' || $cfg['twilio_auth_token'] === '' || $cfg['twilio_from'] === '') return false;
    $to = normalize_phone_e164($to);
    if ($to === '') return false;
    $url = 'https://api.twilio.com/2010-04-01/Accounts/' . rawurlencode($cfg['twilio_account_sid']) . '/Messages.json';
    $auth = base64_encode($cfg['twilio_account_sid'] . ':' . $cfg['twilio_auth_token']);
    $body = http_build_query(['From' => $cfg['twilio_from'], 'To' => $to, 'Body' => $message]);
    $opts = [
        'http' => [
            'method' => 'POST',
            'header' => "Authorization: Basic {$auth}\r\nContent-Type: application/x-www-form-urlencoded\r\n",
            'content' => $body,
            'ignore_errors' => true,
            'timeout' => 20,
        ],
    ];
    $context = stream_context_create($opts);
    $raw = @file_get_contents($url, false, $context);
    $decoded = $raw !== false ? json_decode($raw, true) : null;
    return is_array($decoded) && !empty($decoded['sid']);
}

/**
 * Send an appointment SMS through the configured provider.
 * Returns true only when a provider is configured and the send succeeds.
 * When no credentials are present it returns false so callers can fall back
 * to email + WhatsApp link.
 */
function send_appointment_sms(array $appointment, string $action, ?PDO $pdo = null): bool {
    $cfg = app_config();
    $done = false;
    $error = 'SMS provider not configured';
    $message = appointment_channel_message($appointment, $action);
    if ($cfg['sms_enabled'] && $cfg['sms_provider'] !== '') {
        $recipient = normalize_phone_e164((string) ($appointment['phone'] ?? ''));
        if ($recipient === '') {
            $error = 'No valid phone number on the appointment';
        } elseif ($cfg['sms_provider'] === 'termii') {
            $done = send_sms_via_termii($recipient, $message);
            $error = $done ? null : 'Termii send failed or rejected';
        } elseif ($cfg['sms_provider'] === 'twilio') {
            $done = send_sms_via_twilio($recipient, $message);
            $error = $done ? null : 'Twilio send failed or rejected';
        } else {
            $error = 'Unknown SMS provider "' . $cfg['sms_provider'] . '" (use "termii" or "twilio")';
        }
    }
    if ($pdo) {
        log_notification($pdo, [
            'appointment_id' => $appointment['id'] ?? null,
            'channel'        => 'sms',
            'recipient'      => $appointment['phone'] ?? '',
            'subject'        => 'Appointment ' . $action,
            'body'           => $message,
            'status'         => $done ? 'sent' : 'failed',
            'error'          => $done ? null : $error,
            'sent_at'        => $done ? date('Y-m-d H:i:s') : null,
        ]);
    }
    return $done;
}

/**
 * Send an appointment WhatsApp message through the WhatsApp Business Cloud
 * API (Meta). Returns true only when the API confirms the message.
 * When no credentials are present it returns false and callers fall back to
 * the pre-filled WhatsApp link (see whatsapp_confirmation_link).
 */
function send_whatsapp_message(array $appointment, string $action, ?PDO $pdo = null): bool {
    $cfg = app_config();
    $done = false;
    $error = 'WhatsApp provider not configured';
    $message = appointment_channel_message($appointment, $action);
    if ($cfg['whatsapp_phone_number_id'] !== '' && $cfg['whatsapp_access_token'] !== '') {
        $to = normalize_phone_e164((string) ($appointment['phone'] ?? ''));
        if ($to === '') {
            $error = 'No valid phone number on the appointment';
        } else {
            $body = json_encode([
                'messaging_product' => 'whatsapp',
                'to'                => $to,
                'type'              => 'text',
                'text'              => ['body' => $message],
            ], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
            $url = 'https://graph.facebook.com/v18.0/' . rawurlencode($cfg['whatsapp_phone_number_id']) . '/messages';
            $resp = notifier_http_post(
                $url,
                ['Authorization: Bearer ' . $cfg['whatsapp_access_token'], 'Content-Type: application/json'],
                $body
            );
            $done = is_array($resp) && !empty($resp['messages'][0]['id']);
            $error = $done ? null : ($resp['error']['message'] ?? 'WhatsApp send failed');
        }
    }
    if ($pdo) {
        log_notification($pdo, [
            'appointment_id' => $appointment['id'] ?? null,
            'channel'        => 'whatsapp',
            'recipient'      => $appointment['phone'] ?? '',
            'subject'        => 'Appointment ' . $action,
            'body'           => $message,
            'status'         => $done ? 'sent' : 'failed',
            'error'          => $done ? null : $error,
            'sent_at'        => $done ? date('Y-m-d H:i:s') : null,
        ]);
    }
    return $done;
}

/** Send all configured channels for an appointment action. Email always; SMS/WhatsApp if configured. */
function send_appointment_notification(array $appointment, string $action, ?PDO $pdo = null): void {
    send_appointment_email($appointment, $action, $pdo);
    send_appointment_sms($appointment, $action, $pdo);
    send_whatsapp_message($appointment, $action, $pdo);
}

/** Compose and send a reminder for an upcoming (confirmed) appointment. */
function send_appointment_reminder(array $appointment, ?PDO $pdo = null): bool {
    $cfg = app_config();
    $subject = sprintf('[%s] Appointment reminder', $appointment['booking_code']);
    $body = "Hello {$appointment['patient_name']},\n\n" .
        "This is a reminder of your upcoming appointment.\n" .
        "Reference: {$appointment['booking_code']}\n" .
        "Service: {$appointment['service_name']}\n" .
        "Location: {$appointment['location_name']}\n" .
        "Date and time: {$appointment['appointment_at']}\n\n" .
        "Manage, reschedule, or cancel your request: " . appointment_manage_url($appointment) . "\n\n" .
        "This service is not for emergencies. If this is an emergency, seek immediate emergency medical care or call {$cfg['clinic_phone']}.\n";
    $ok = false;
    if ($cfg['mail_from'] !== '' && filter_var($appointment['email'], FILTER_VALIDATE_EMAIL)) {
        $headers = [
            'From: ' . $cfg['mail_from_name'] . ' <' . $cfg['mail_from'] . '>',
            'Reply-To: ' . ($cfg['mail_reply_to'] ?: $cfg['mail_from']),
            'Content-Type: text/plain; charset=UTF-8',
        ];
        $ok = @mail($appointment['email'], $subject, $body, implode("\r\n", $headers));
    }
    if ($pdo) {
        log_notification($pdo, [
            'appointment_id' => $appointment['id'] ?? null,
            'channel'        => 'email',
            'recipient'      => $appointment['email'] ?? '',
            'subject'        => $subject,
            'body'           => $body,
            'status'         => $ok ? 'sent' : 'failed',
            'error'          => $ok ? null : 'Reminder email send failed',
            'sent_at'        => $ok ? date('Y-m-d H:i:s') : null,
        ]);
    }
    // Also try SMS/WhatsApp if configured.
    send_appointment_sms($appointment, 'reminder', $pdo);
    send_whatsapp_message($appointment, 'reminder', $pdo);
    return $ok;
}
