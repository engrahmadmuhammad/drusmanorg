# Appointment backend (pure PHP + MySQL)

This is a shared-hosting-friendly appointment API. It has no Composer or framework dependency.

## Install

1. Create a MySQL database and database user in cPanel.
2. For a new install, import `database/schema.sql` in phpMyAdmin. This file is the complete fresh-install structure and already creates staff users, patients, locations, services, availability, appointments, notifications, contact messages, content videos, payments, and audit history tables.
3. Do not run `database/migrations/*.sql` after importing the fresh schema. The migration files are only for upgrading an older database that was created before those tables/columns existed.
4. Optional: import `database/seed.sql` for starter data. It includes sample locations, services with pricing/deposits, availability, patients, and public videos. It intentionally does not create staff accounts, so the first-administrator setup still works.
5. Copy `.env.example` to `.env`, then enter the database and mail settings. Do not commit `.env`. The `.env.example` file documents every supported setting, including all SMS/WhatsApp provider keys, so you can enable or disable a provider by filling in (or leaving blank) its credentials.
6. Add the real clinic location, services, prices/deposits, and availability rules before accepting appointments. You can use the staff portal for this after creating the first administrator.
7. Upload the project. Keep `backend/.env` and `backend/src/` outside the public web directory if your host allows it. Set the web-accessible backend directory to `backend/public/`.
8. Ensure PHP 8.1+ with PDO MySQL is enabled. The `.htaccess` file disables directory indexes and supports clean routes; the front end uses `index.php?route=...`, so it also works where rewrites are unavailable.
9. Set `APP_URL` to the public site URL. This makes appointment-management links in confirmation emails correct.

## Upgrading an older database

If an older database was created from an earlier `schema.sql`, run only the migrations that correspond to missing features, in numeric order:

- `002_staff_portal.sql` adds staff accounts, audit logs, and service pricing.
- `003_content_admin.sql` adds database-backed video management.
- `004_patients_notifications.sql` adds patients, appointment patient links, notification logs, and contact messages.
- `005_payments_reminders.sql` adds service deposits and the payment ledger.

Do not run a migration if the target table or column already exists.

## Notifications

PHP's `mail()` sends appointment email when the host supports it. Configure a domain mailbox in `MAIL_FROM`; for dependable delivery, configure the host's SMTP relay or replace `send_appointment_email()` with an SMTP provider integration.

### SMS (Termii or Twilio)

Automated SMS is config-driven in `src/notifier.php` and requires credentials in `backend/.env`:

1. Set `SMS_ENABLED=true`.
2. Set `SMS_PROVIDER=termii` or `SMS_PROVIDER=twilio`.
3. Fill in the matching credentials:
   - **Termii**: `TERMII_API_KEY` and `TERMII_SENDER` (your approved sender ID).
   - **Twilio**: `TWILIO_ACCOUNT_SID`, `TWILIO_AUTH_TOKEN`, and `TWILIO_FROM` (a Twilio phone number in E.164 form).

When the configured provider is set and the send succeeds, the attempt is logged in the `notifications` table with channel `sms`. If SMS is disabled (or credentials are blank), the app silently falls back to email + WhatsApp link and no SMS is attempted.

### WhatsApp

Two ways to use WhatsApp:

- **Click-to-chat link (recommended for a new clinic):** set `WHATSAPP_CLICK_LINK` to your WhatsApp Business click-to-chat URL (for example `https://wa.me/message/VEALYDXXF4PDF1`). The API then returns this link as the confirmation link, and public pages can point at it. If the link is blank, the app falls back to a `wa.me/<WHATSAPP_NUMBER>` link with the booking summary.
- **Automated messages (WhatsApp Business Cloud API):** set `WHATSAPP_PHONE_NUMBER_ID` and `WHATSAPP_ACCESS_TOKEN` (and optionally `WHATSAPP_BUSINESS_ACCOUNT_ID`) in `backend/.env`. When these are present, appointment actions and reminders are sent as WhatsApp text messages via the Meta Graph API. When they are blank, automated sending is disabled and the app falls back to the click-to-chat / wa.me link.

### Disabling providers

Leave the provider credentials blank (and keep `SMS_ENABLED=false` for SMS) to disable automated SMS/WhatsApp entirely. The system then relies on email plus the pre-filled WhatsApp link, which is the safest default for a new deployment.

### Reminders

`backend/scripts/send_reminders.php` is a CLI cron script (see its header for an example crontab line). It finds upcoming confirmed appointments inside the configured `REMINDER_HOURS` window, sends email (and SMS/WhatsApp if configured), and de-duplicates using the `notifications` table so the same appointment is not reminded twice.

## Patient API

- `GET index.php?route=locations`
- `GET index.php?route=services`
- `GET index.php?route=slots&location_id=1&service_id=1&date=YYYY-MM-DD`
- `POST index.php?route=appointments`
- `GET index.php?route=appointment&code=...&token=...`
- `POST index.php?route=appointments/cancel`
- `POST index.php?route=appointments/reschedule`
- `POST index.php?route=contact/messages` saves telemedicine/contact form submissions to the `contact_messages` inbox.
- `POST index.php?route=payments/initialize`
- `GET index.php?route=payments/verify&reference=...`
- `GET index.php?route=payments/status&code=...&token=...`

New appointment requests have status `pending`. Staff can approve, reschedule, cancel, complete, or mark no-show from the staff portal.

## Staff portal

Open `front end/staff.html` only from the same HTTPS domain as the backend. It is separate from the video/content admin page.

Before the first use, place a random 32+ character `SETUP_ADMIN_TOKEN` in `backend/.env`. On the staff sign-in page, open **First administrator setup** and provide that token with the administrator's name, email, and a strong password (12+ characters with upper/lower case, number, and symbol). Bootstrap is permanently disabled after the first account is created; remove `SETUP_ADMIN_TOKEN` from `.env` after setup.

Roles:

- `admin`: manages locations, services, prices, availability, blocked times, staff accounts, and appointments.
- `scheduler`: views appointments and changes their status/reschedules them.
- `clinician`: views appointments and updates attendance/status.

All state-changing staff requests use a server session and CSRF token. The backend writes staff actions to `audit_logs`.

## Content administration

`front end/admin.html` is a separate, administrator-only video-content portal. It uses the same secure staff accounts but has no appointment calendar or patient data. The previous browser-only demo credentials and localStorage dashboard have been removed from the active admin page.
