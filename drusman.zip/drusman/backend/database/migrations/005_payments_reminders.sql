-- 005_payments_reminders.sql
-- Adds a payments ledger and a nullable deposit amount on services.
-- Run AFTER 004 (patients/notifications) on top of a fresh schema.
-- Usage: mysql -u USER -p DBNAME < 005_payments_reminders.sql

-- ---------------------------------------------------------------------------
-- Optional consultation deposit configured per service. NULL/0 means the
-- service does not require a deposit at booking time.
-- ---------------------------------------------------------------------------
ALTER TABLE services ADD COLUMN deposit_amount_ngn DECIMAL(12,2) NULL AFTER price_ngn;

-- ---------------------------------------------------------------------------
-- payments: server-verified payment ledger. A payment is only ever recorded
-- as paid after a server-to-server verification (Paystack verify API) or a
-- signed webhook. Browser callbacks are never treated as proof of payment.
-- ---------------------------------------------------------------------------
CREATE TABLE payments (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  appointment_id BIGINT UNSIGNED NOT NULL,
  reference VARCHAR(120) NOT NULL COMMENT 'Gateway payment reference (unique per provider)',
  provider ENUM('paystack','flutterwave') NOT NULL DEFAULT 'paystack',
  amount_ngn DECIMAL(12,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'NGN',
  status ENUM('pending','paid','failed','refunded') NOT NULL DEFAULT 'pending',
  gateway_response TEXT NULL COMMENT 'Raw gateway response for audit',
  metadata JSON NULL,
  verified_at DATETIME NULL COMMENT 'Set only when server-side verification confirms payment',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  CONSTRAINT fk_payment_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE,
  UNIQUE KEY uq_payment_reference (reference),
  INDEX idx_payments_appointment (appointment_id),
  INDEX idx_payments_status (status, created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
