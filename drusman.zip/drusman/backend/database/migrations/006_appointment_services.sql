-- 006_appointment_services.sql
-- Adds additional surgical/consultation services so they appear in the
-- appointment form's "1. Service" dropdown.
-- Run AFTER 005 (payments/reminders) on top of a fresh schema, or on any
-- existing database that does not already contain these services.
-- Usage: mysql -u USER -p DBNAME < 006_appointment_services.sql
--
-- Price, duration, and deposit are optional (NULL) where not specified,
-- matching the services table definition. To require a booking deposit for
-- any service, set deposit_amount_ngn to a value between 100 and 1000000.

INSERT INTO services (name, description, duration_minutes, price_ngn, deposit_amount_ngn, active) VALUES
('Cholecystectomy', 'Surgical removal of the gallbladder.', 120, NULL, NULL, 1),
('Appendectomy', 'Surgical removal of the appendix.', 90, NULL, NULL, 1),
('Diagnostic Laparoscopy', 'Minimally invasive examination of the abdomen.', 60, NULL, NULL, 1),
('Hernia Repair', 'Surgical correction of a hernia.', 120, NULL, NULL, 1),
('Laparoscopic Adhesiolysis', 'Removal of abdominal scar tissue (adhesions).', 90, NULL, NULL, 1),
('Laparoscopic Nissen Fundoplication', 'Surgical treatment for acid reflux (GERD).', 120, NULL, NULL, 1);
