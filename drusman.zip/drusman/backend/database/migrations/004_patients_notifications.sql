-- 004_patients_notifications.sql
-- Adds a patient registry, a notification log, and a contact/telemedicine
-- message inbox. Run AFTER 001 (schema), 002 (staff), 003 (content).
-- Usage: mysql -u USER -p DBNAME < 004_patients_notifications.sql

-- ---------------------------------------------------------------------------
-- patients: a growing registry of people who have interacted with the clinic.
-- Appointment rows keep their embedded name/email/phone for non-breaking
-- reads, but they may also reference a patients row for reporting.
-- ---------------------------------------------------------------------------
CREATE TABLE patients (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  email VARCHAR(190) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  UNIQUE KEY uq_patients_email (email),
  INDEX idx_patients_phone (phone)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Link appointments to the patient registry (nullable, non-breaking).
ALTER TABLE appointments ADD COLUMN patient_id INT UNSIGNED NULL AFTER manage_token;
ALTER TABLE appointments
  ADD CONSTRAINT fk_appointment_patient
  FOREIGN KEY (patient_id) REFERENCES patients(id)
  ON DELETE SET NULL;

-- ---------------------------------------------------------------------------
-- notifications: records every outbound email/whatsapp/sms attempt so staff
-- can audit delivery and retry failures.
-- ---------------------------------------------------------------------------
CREATE TABLE notifications (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  appointment_id BIGINT UNSIGNED NULL,
  channel ENUM('email','whatsapp','sms') NOT NULL DEFAULT 'email',
  recipient VARCHAR(190) NOT NULL,
  subject VARCHAR(255) NULL,
  body TEXT NULL,
  status ENUM('pending','sent','failed') NOT NULL DEFAULT 'pending',
  error VARCHAR(255) NULL,
  sent_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_notification_appointment FOREIGN KEY (appointment_id) REFERENCES appointments(id) ON DELETE CASCADE,
  INDEX idx_notifications_status (status, created_at),
  INDEX idx_notifications_channel (channel)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- ---------------------------------------------------------------------------
-- contact_messages: inbox for the public telemedicine/contact form.
-- ---------------------------------------------------------------------------
CREATE TABLE contact_messages (
  id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(160) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(190) NULL,
  preferred_date DATE NULL,
  subject VARCHAR(190) NULL,
  message TEXT NOT NULL,
  status ENUM('new','read','replied') NOT NULL DEFAULT 'new',
  ip_address VARCHAR(45) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
