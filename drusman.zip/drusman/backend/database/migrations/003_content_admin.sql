CREATE TABLE content_videos (
  id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(180) NOT NULL,
  subtitle VARCHAR(255) NULL,
  youtube_url VARCHAR(255) NOT NULL,
  duration_label VARCHAR(40) NULL,
  featured TINYINT(1) NOT NULL DEFAULT 0,
  published TINYINT(1) NOT NULL DEFAULT 1,
  sort_order SMALLINT UNSIGNED NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX idx_content_videos_public (published, featured, sort_order)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO content_videos (title, subtitle, youtube_url, duration_label, featured, sort_order) VALUES
('Laparoscopic Cholecystectomy', 'Gallbladder removal procedure', 'https://www.youtube.com/watch?v=MLms3yBRsgc', '12 min', 1, 1),
('Laparoscopic Appendectomy', 'Appendix removal via laparoscopy', 'https://www.youtube.com/watch?v=VB4y9Da6bLY', '10 min', 1, 2),
('Diagnostic Laparoscopy', 'Examination and assessment', 'https://www.youtube.com/watch?v=35HiyJpH11U', '8 min', 1, 3),
('Laparoscopic Hernia Repair', 'Hernia repair via minimally invasive approach', 'https://www.youtube.com/watch?v=eJ3KEZ0mz1k', '14 min', 1, 4);
