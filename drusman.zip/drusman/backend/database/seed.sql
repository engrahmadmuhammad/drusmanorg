-- seed.sql
-- Optional starter data for a fresh install. Run AFTER database/schema.sql.
-- Do not run migration files on a fresh database created from schema.sql.

-- Staff users are intentionally not seeded. Create the first administrator
-- through the staff portal using SETUP_ADMIN_TOKEN.

-- Locations. Replace with the verified clinic address.
INSERT INTO locations (name, address, phone) VALUES
('Main Consultation Clinic', 'No 2 Dabino Avenue, Hotoro GRA, Kano', '08036893332');

-- Services with pricing and optional booking deposits (NGN).
INSERT INTO services (name, description, duration_minutes, price_ngn, deposit_amount_ngn) VALUES
('General Surgical Consultation', 'Initial consultation and assessment.', 30, 250000.00, 25000.00),
('Follow-up Consultation', 'Follow-up after a previous consultation or procedure.', 20, 150000.00, 15000.00),
('Telemedicine Consultation', 'Remote consultation, subject to clinical suitability.', 30, 200000.00, 20000.00),
('Laparoscopic Cholecystectomy', 'Gallbladder removal via minimally invasive approach.', 120, 1200000.00, NULL),
('Laparoscopic Appendectomy', 'Appendix removal via laparoscopy.', 90, 800000.00, NULL),
('Laparoscopic Hernia Repair', 'Hernia repair via minimally invasive approach.', 120, 1000000.00, NULL);

-- Weekly availability (Mon-Fri 09:00-16:00, Sat 09:00-13:00).
INSERT INTO availability_rules (location_id, weekday, starts_at, ends_at, slot_minutes) VALUES
(1, 1, '09:00:00', '16:00:00', 30),
(1, 2, '09:00:00', '16:00:00', 30),
(1, 3, '09:00:00', '16:00:00', 30),
(1, 4, '09:00:00', '16:00:00', 30),
(1, 5, '09:00:00', '16:00:00', 30),
(1, 6, '09:00:00', '13:00:00', 30);

-- Sample patients.
INSERT INTO patients (name, email, phone) VALUES
('Amina Yusuf', 'amina.yusuf@example.com', '+2348012345678'),
('Sani Abdullahi', 'sani.abdul@example.com', '+2348023456789');

-- Sample public videos.
INSERT INTO content_videos (title, subtitle, youtube_url, duration_label, featured, sort_order) VALUES
('Laparoscopic Cholecystectomy', 'Gallbladder removal procedure', 'https://www.youtube.com/watch?v=MLms3yBRsgc', '12 min', 1, 1),
('Laparoscopic Appendectomy', 'Appendix removal via laparoscopy', 'https://www.youtube.com/watch?v=VB4y9Da6bLY', '10 min', 1, 2),
('Diagnostic Laparoscopy', 'Examination and assessment', 'https://www.youtube.com/watch?v=35HiyJpH11U', '8 min', 1, 3),
('Laparoscopic Hernia Repair', 'Hernia repair via minimally invasive approach', 'https://www.youtube.com/watch?v=eJ3KEZ0mz1k', '14 min', 1, 4);
