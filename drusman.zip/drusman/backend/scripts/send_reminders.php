<?php
declare(strict_types=1);

/**
 * CLI script to send appointment reminders for upcoming confirmed
 * appointments. Run via cron, e.g.:
 *
 *   0 * * * * php /path/to/backend/scripts/send_reminders.php
 *
 * Uses the notifications table to avoid sending the same reminder twice.
 */

require_once __DIR__ . '/../src/config.php';
require_once __DIR__ . '/../src/db.php';
require_once __DIR__ . '/../src/notifier.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("This script may only be run from the command line.\n");
}

$cfg = app_config();
$pdo = db();

$hours = max(1, (int) ($cfg['reminder_hours'] ?: 24));
$windowStart = date('Y-m-d H:i:s', time() + $hours * 3600);
// Allow a 6-hour late window so cron gaps still catch appointments.
$windowEnd   = date('Y-m-d H:i:s', time() + ($hours + 6) * 3600);

// Upcoming confirmed appointments in the reminder window that have not
// already received a reminder email for the same appointment.
$sql = "
    SELECT a.*, l.name AS location_name, s.name AS service_name
    FROM appointments a
    JOIN locations l ON l.id = a.location_id
    JOIN services  s ON s.id = a.service_id
    WHERE a.status = 'confirmed'
      AND a.appointment_at BETWEEN ? AND ?
      AND NOT EXISTS (
        SELECT 1 FROM notifications n
        WHERE n.appointment_id = a.id
          AND n.channel = 'email'
          AND n.subject LIKE '%reminder%'
          AND n.status = 'sent'
      )
    ORDER BY a.appointment_at
";
$stmt = $pdo->prepare($sql);
$stmt->execute([$windowStart, $windowEnd]);
$appointments = $stmt->fetchAll();

$sent = 0;
$failed = 0;
foreach ($appointments as $appointment) {
    if (send_appointment_reminder($appointment, $pdo)) {
        $sent++;
    } else {
        $failed++;
    }
}

echo sprintf(
    "Reminder run at %s: %d appointments in window, %d sent, %d logged-failed.\n",
    date('Y-m-d H:i:s'),
    count($appointments),
    $sent,
    $failed
);
