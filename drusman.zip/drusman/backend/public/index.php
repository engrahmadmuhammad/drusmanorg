<?php
declare(strict_types=1);

require_once __DIR__ . '/../src/config.php';
require_once __DIR__ . '/../src/db.php';
require_once __DIR__ . '/../src/notifier.php';
require_once __DIR__ . '/../src/payments.php';
require_once __DIR__ . '/../src/staff_portal.php';

header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
if (($_SERVER['REQUEST_METHOD'] ?? 'GET') === 'OPTIONS') json_response(['ok' => true], 204);

function route(): string {
    if (isset($_GET['route'])) return trim((string) $_GET['route'], '/');
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '', PHP_URL_PATH) ?: '';
    $script = str_replace('\\', '/', $_SERVER['SCRIPT_NAME'] ?? '/index.php');
    if (str_starts_with($path, $script)) $path = substr($path, strlen($script));
    return trim($path, '/');
}

function required_string(array $input, string $field, int $minimum = 1, int $maximum = 5000): string {
    $value = trim((string) ($input[$field] ?? ''));
    if (text_length($value) < $minimum || text_length($value) > $maximum) {
        json_response(['error' => "Please provide a valid {$field}."], 422);
    }
    return $value;
}

function appointment_details(PDO $pdo, string $code, string $token): ?array {
    $stmt = $pdo->prepare('SELECT a.*, l.name AS location_name, l.address AS location_address, s.name AS service_name FROM appointments a JOIN locations l ON l.id = a.location_id JOIN services s ON s.id = a.service_id WHERE a.booking_code = ? AND a.manage_token = ? LIMIT 1');
    $stmt->execute([$code, $token]);
    return $stmt->fetch() ?: null;
}

function make_booking_code(PDO $pdo): string {
    do {
        $code = 'UMB-' . strtoupper(bin2hex(random_bytes(3)));
        $stmt = $pdo->prepare('SELECT 1 FROM appointments WHERE booking_code = ?');
        $stmt->execute([$code]);
    } while ($stmt->fetchColumn());
    return $code;
}

function valid_slot(PDO $pdo, int $locationId, int $serviceId, DateTimeImmutable $start, ?int $excludeId = null): array|false {
    $service = $pdo->prepare('SELECT duration_minutes FROM services WHERE id = ? AND active = 1');
    $service->execute([$serviceId]);
    $duration = $service->fetchColumn();
    if (!$duration) return false;
    $end = $start->modify('+' . (int) $duration . ' minutes');
    $weekday = (int) $start->format('N');
    $rules = $pdo->prepare('SELECT starts_at, ends_at, slot_minutes FROM availability_rules WHERE location_id = ? AND weekday = ? AND active = 1');
    $rules->execute([$locationId, $weekday]);
    $fitsRule = false;
    foreach ($rules->fetchAll() as $rule) {
        $ruleStart = new DateTimeImmutable($start->format('Y-m-d') . ' ' . $rule['starts_at']);
        $ruleEnd = new DateTimeImmutable($start->format('Y-m-d') . ' ' . $rule['ends_at']);
        $minutesFromRuleStart = ($start->getTimestamp() - $ruleStart->getTimestamp()) / 60;
        if ($start >= $ruleStart && $end <= $ruleEnd && $minutesFromRuleStart % (int) $rule['slot_minutes'] === 0) $fitsRule = true;
    }
    if (!$fitsRule) return false;
    $block = $pdo->prepare('SELECT 1 FROM blocked_slots WHERE location_id = ? AND starts_at < ? AND ends_at > ? LIMIT 1');
    $block->execute([$locationId, $end->format('Y-m-d H:i:s'), $start->format('Y-m-d H:i:s')]);
    if ($block->fetchColumn()) return false;
    $sql = 'SELECT 1 FROM appointments WHERE location_id = ? AND status IN (\'pending\', \'confirmed\') AND appointment_at < ? AND DATE_ADD(appointment_at, INTERVAL duration_minutes MINUTE) > ?';
    $params = [$locationId, $end->format('Y-m-d H:i:s'), $start->format('Y-m-d H:i:s')];
    if ($excludeId !== null) { $sql .= ' AND id != ?'; $params[] = $excludeId; }
    $conflict = $pdo->prepare($sql);
    $conflict->execute($params);
    if ($conflict->fetchColumn()) return false;
    return ['duration' => (int) $duration, 'end' => $end];
}

function slots_for_date(PDO $pdo, int $locationId, int $serviceId, DateTimeImmutable $date): array {
    if ($date < new DateTimeImmutable('today') || $date > new DateTimeImmutable('+90 days')) return [];
    $rules = $pdo->prepare('SELECT starts_at, ends_at, slot_minutes FROM availability_rules WHERE location_id = ? AND weekday = ? AND active = 1');
    $rules->execute([$locationId, (int) $date->format('N')]);
    $slots = [];
    foreach ($rules->fetchAll() as $rule) {
        $cursor = new DateTimeImmutable($date->format('Y-m-d') . ' ' . $rule['starts_at']);
        $endsAt = new DateTimeImmutable($date->format('Y-m-d') . ' ' . $rule['ends_at']);
        while ($cursor < $endsAt) {
            if ($cursor > new DateTimeImmutable('+2 hours') && valid_slot($pdo, $locationId, $serviceId, $cursor)) {
                $slots[] = $cursor->format('H:i');
            }
            $cursor = $cursor->modify('+' . (int) $rule['slot_minutes'] . ' minutes');
        }
    }
    return array_values(array_unique($slots));
}

try {
    $pdo = db();
    $method = $_SERVER['REQUEST_METHOD'] ?? 'GET';
    $route = route();

    if (dispatch_staff_route($pdo, $method, $route)) exit;

    if ($method === 'GET' && $route === 'content/videos') {
        $stmt = $pdo->query('SELECT id, title, subtitle, youtube_url, duration_label, featured FROM content_videos WHERE published = 1 ORDER BY featured DESC, sort_order ASC, created_at DESC');
        json_response(['videos' => $stmt->fetchAll()]);
    }

if ($method === 'POST' && $route === 'contact/messages') {
        $input = request_json();
        if (trim((string) ($input['website'] ?? '')) !== '') json_response(['ok' => true], 201); // honeypot
        $name = required_string($input, 'name', 2, 160);
        $phone = required_string($input, 'phone', 7, 40);
        $message = required_string($input, 'message', 10, 3000);
        $email = trim((string) ($input['email'] ?? ''));
        $subject = trim((string) ($input['subject'] ?? ''));
        $preferredDate = trim((string) ($input['preferred_date'] ?? ''));
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) json_response(['error' => 'Please provide a valid email address or leave it blank.'], 422);
        if ($preferredDate !== '') {
            $d = DateTimeImmutable::createFromFormat('!Y-m-d', $preferredDate);
            if (!$d || $d->format('Y-m-d') !== $preferredDate) json_response(['error' => 'Please provide a valid preferred date.'], 422);
        }
        $stmt = $pdo->prepare('INSERT INTO contact_messages (name, phone, email, preferred_date, subject, message, ip_address) VALUES (?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$name, $phone, $email !== '' ? $email : null, $preferredDate !== '' ? $preferredDate : null, $subject !== '' ? $subject : null, $message, $_SERVER['REMOTE_ADDR'] ?? null]);
        json_response(['ok' => true, 'message' => 'Your request has been received. We will contact you shortly.'], 201);
    }
    if ($method === 'GET' && $route === 'locations') {
        json_response(['locations' => $pdo->query('SELECT id, name, address, phone FROM locations WHERE active = 1 ORDER BY name')->fetchAll()]);
    }
    if ($method === 'GET' && $route === 'services') {
        json_response(['services' => $pdo->query('SELECT id, name, description, duration_minutes FROM services WHERE active = 1 ORDER BY name')->fetchAll()]);
    }
    if ($method === 'GET' && $route === 'slots') {
        $locationId = filter_input(INPUT_GET, 'location_id', FILTER_VALIDATE_INT);
        $serviceId = filter_input(INPUT_GET, 'service_id', FILTER_VALIDATE_INT);
        $date = DateTimeImmutable::createFromFormat('!Y-m-d', (string) ($_GET['date'] ?? ''));
        if (!$locationId || !$serviceId || !$date || $date->format('Y-m-d') !== ($_GET['date'] ?? '')) json_response(['error' => 'A valid location, service, and date are required.'], 422);
        json_response(['slots' => slots_for_date($pdo, $locationId, $serviceId, $date)]);
    }
    if ($method === 'POST' && $route === 'appointments') {
        $input = request_json();
        if (trim((string) ($input['website'] ?? '')) !== '') json_response(['ok' => true], 201); // honeypot
        $locationId = filter_var($input['location_id'] ?? null, FILTER_VALIDATE_INT);
        $serviceId = filter_var($input['service_id'] ?? null, FILTER_VALIDATE_INT);
        $date = required_string($input, 'date', 10, 10);
        $time = required_string($input, 'time', 5, 5);
        $patient = required_string($input, 'patient_name', 2, 160);
        $email = required_string($input, 'email', 5, 190);
        $phone = required_string($input, 'phone', 7, 40);
        $reason = required_string($input, 'reason', 10, 3000);
        if (!filter_var($input['consent'] ?? false, FILTER_VALIDATE_BOOL)) {
            json_response(['error' => 'You must confirm the appointment and privacy notice before submitting.'], 422);
        }
        if (!$locationId || !$serviceId || !filter_var($email, FILTER_VALIDATE_EMAIL)) json_response(['error' => 'Please provide valid appointment details and email address.'], 422);
        $start = DateTimeImmutable::createFromFormat('!Y-m-d H:i', "$date $time");
        if (!$start || $start->format('Y-m-d H:i') !== "$date $time" || $start <= new DateTimeImmutable('+2 hours')) json_response(['error' => 'Please choose a future time at least two hours from now.'], 422);
        $pdo->beginTransaction();
        $slot = valid_slot($pdo, $locationId, $serviceId, $start);
        if (!$slot) { $pdo->rollBack(); json_response(['error' => 'That time is no longer available. Please choose another slot.'], 409); }
        $code = make_booking_code($pdo);
        $token = bin2hex(random_bytes(32));
$stmt = $pdo->prepare('INSERT INTO appointments (booking_code, manage_token, location_id, service_id, appointment_at, duration_minutes, patient_name, email, phone, reason) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)');
        $stmt->execute([$code, $token, $locationId, $serviceId, $start->format('Y-m-d H:i:s'), $slot['duration'], $patient, $email, $phone, $reason]);
        $id = (int) $pdo->lastInsertId();
        // Register the patient (growing registry) so appointments link to a patient row.
        $findPatient = $pdo->prepare('SELECT id FROM patients WHERE email = ? LIMIT 1');
        $findPatient->execute([strtolower($email)]);
        $patientId = $findPatient->fetchColumn();
        if (!$patientId) {
            $pdo->prepare('INSERT INTO patients (name, email, phone) VALUES (?, ?, ?)')->execute([$patient, strtolower($email), $phone]);
            $patientId = (int) $pdo->lastInsertId();
        }
        $pdo->prepare('UPDATE appointments SET patient_id = ? WHERE id = ?')->execute([$patientId, $id]);
        $pdo->commit();
$appointment = appointment_details($pdo, $code, $token);
        send_appointment_notification($appointment, 'received', $pdo);
        $deposit = appointment_deposit_amount($pdo, $appointment);
        json_response(['ok' => true, 'appointment' => ['code' => $code, 'token' => $token, 'appointment_at' => $appointment['appointment_at'], 'location_name' => $appointment['location_name'], 'service_name' => $appointment['service_name'], 'status' => 'pending', 'whatsapp_url' => whatsapp_confirmation_link($appointment), 'deposit_amount' => $deposit]], 201);
    }
if ($method === 'GET' && $route === 'appointment') {
        $code = required_string($_GET, 'code', 8, 10);
        $token = required_string($_GET, 'token', 64, 64);
        $appointment = appointment_details($pdo, $code, $token);
        if (!$appointment) json_response(['error' => 'Appointment not found.'], 404);
        $payment = payment_for_appointment($pdo, (int) $appointment['id']);
        json_response(['appointment' => ['code' => $appointment['booking_code'], 'location_id' => $appointment['location_id'], 'service_id' => $appointment['service_id'], 'location_name' => $appointment['location_name'], 'location_address' => $appointment['location_address'], 'service_name' => $appointment['service_name'], 'appointment_at' => $appointment['appointment_at'], 'status' => $appointment['status'], 'patient_name' => $appointment['patient_name'], 'deposit_amount' => appointment_deposit_amount($pdo, $appointment), 'payment' => $payment ? ['status' => $payment['status'], 'amount_ngn' => $payment['amount_ngn'], 'reference' => $payment['reference']] : null]]);
    }
    if ($method === 'POST' && $route === 'payments/initialize') {
        $input = request_json();
        $code = required_string($input, 'code', 8, 10);
        $token = required_string($input, 'token', 64, 64);
        $appointment = appointment_details($pdo, $code, $token);
        if (!$appointment) json_response(['error' => 'Appointment not found.'], 404);
        if (in_array($appointment['status'], ['cancelled', 'completed', 'no_show'], true)) json_response(['error' => 'This appointment can no longer accept a deposit.'], 422);
        $existing = payment_for_appointment($pdo, (int) $appointment['id']);
        if ($existing && $existing['status'] === 'paid') json_response(['error' => 'This deposit has already been paid.'], 409);
        $deposit = appointment_deposit_amount($pdo, $appointment);
        if ($deposit === null) json_response(['error' => 'No deposit is required for this service.'], 422);
        $cfg = app_config();
        $callback = rtrim($cfg['app_url'], '/') . '/front%20end/manage-appointment.html?code=' . rawurlencode($code) . '&token=' . rawurlencode($token);
        try {
            $init = paystack_initialize($pdo, $appointment, $deposit, $appointment['email'], $callback);
            json_response(['ok' => true, 'authorization_url' => $init['authorization_url'], 'reference' => $init['reference']]);
        } catch (Throwable $e) {
            json_response(['error' => $e->getMessage()], 502);
        }
    }
    if ($method === 'GET' && $route === 'payments/verify') {
        $reference = required_string($_GET, 'reference', 8, 120);
        // Optional: verify the caller controls the appointment.
        $code = trim((string) ($_GET['code'] ?? ''));
        $token = trim((string) ($_GET['token'] ?? ''));
        if ($code !== '' && $token !== '') {
            $appointment = appointment_details($pdo, $code, $token);
            if (!$appointment) json_response(['error' => 'Appointment not found.'], 404);
        }
        try {
            json_response(paystack_verify($pdo, $reference));
        } catch (Throwable $e) {
            json_response(['error' => $e->getMessage()], 502);
        }
    }
    if ($method === 'GET' && $route === 'payments/status') {
        $code = required_string($_GET, 'code', 8, 10);
        $token = required_string($_GET, 'token', 64, 64);
        $appointment = appointment_details($pdo, $code, $token);
        if (!$appointment) json_response(['error' => 'Appointment not found.'], 404);
        $payment = payment_for_appointment($pdo, (int) $appointment['id']);
        json_response(['payment' => $payment ? ['status' => $payment['status'], 'amount_ngn' => $payment['amount_ngn'], 'reference' => $payment['reference']] : null, 'deposit_amount' => appointment_deposit_amount($pdo, $appointment)]);
    }
    if ($method === 'POST' && $route === 'payments/webhook') {
        $rawBody = (string) file_get_contents('php://input');
        $signature = (string) ($_SERVER['HTTP_X_PAYSTACK_SIGNATURE'] ?? '');
        $handled = handle_paystack_webhook($pdo, $rawBody, $signature);
        http_response_code($handled ? 200 : 400);
        header('Content-Type: application/json; charset=utf-8');
        echo json_encode(['ok' => $handled]);
        exit;
    }
    if ($method === 'POST' && ($route === 'appointments/cancel' || $route === 'appointments/reschedule')) {
        $input = request_json();
        $code = required_string($input, 'code', 8, 10);
        $token = required_string($input, 'token', 64, 64);
        $appointment = appointment_details($pdo, $code, $token);
        if (!$appointment) json_response(['error' => 'Appointment not found.'], 404);
        if (in_array($appointment['status'], ['cancelled', 'completed', 'no_show'], true)) json_response(['error' => 'This appointment can no longer be changed.'], 422);
        if (new DateTimeImmutable($appointment['appointment_at']) <= new DateTimeImmutable('+2 hours')) json_response(['error' => 'Online changes close two hours before the appointment. Please contact the clinic.'], 422);
if ($route === 'appointments/cancel') {
            $pdo->prepare("UPDATE appointments SET status = 'cancelled', cancelled_at = NOW() WHERE id = ?")->execute([$appointment['id']]);
            send_appointment_notification($appointment, 'cancelled', $pdo);
            json_response(['ok' => true, 'message' => 'Your appointment request has been cancelled.']);
        }
        $date = required_string($input, 'date', 10, 10); $time = required_string($input, 'time', 5, 5);
        $start = DateTimeImmutable::createFromFormat('!Y-m-d H:i', "$date $time");
        if (!$start || $start->format('Y-m-d H:i') !== "$date $time" || $start <= new DateTimeImmutable('+2 hours')) json_response(['error' => 'Please choose a valid future time.'], 422);
        $pdo->beginTransaction();
        $slot = valid_slot($pdo, (int)$appointment['location_id'], (int)$appointment['service_id'], $start, (int)$appointment['id']);
        if (!$slot) { $pdo->rollBack(); json_response(['error' => 'That time is no longer available.'], 409); }
        $pdo->prepare('UPDATE appointments SET appointment_at = ?, duration_minutes = ?, status = \'pending\' WHERE id = ?')->execute([$start->format('Y-m-d H:i:s'), $slot['duration'], $appointment['id']]);
        $pdo->commit();
$updated = appointment_details($pdo, $code, $token);
        send_appointment_notification($updated, 'rescheduled', $pdo);
        json_response(['ok' => true, 'appointment_at' => $updated['appointment_at'], 'message' => 'Your new appointment request has been received.']);
    }
    json_response(['error' => 'Not found.'], 404);
} catch (Throwable $exception) {
    error_log('Appointment API: ' . $exception->getMessage());
    json_response(['error' => 'The appointment service is temporarily unavailable. Please try again later or contact the clinic.'], 500);
}
