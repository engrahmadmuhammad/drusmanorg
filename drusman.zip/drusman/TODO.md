# Appointment Services + Deposit Range — TODO

## Steps
- [x] 1. Create `backend/database/migrations/006_appointment_services.sql` — insert 8 services (Cholecystectomy, Appendectomy, Diagnostic Laparoscopy, Hernia Repair, Laparoscopic Sleeve Gastrectomy, Laparoscopic Nissen Fundoplication, Laparoscopic Adhesiolysis, General Surgery) so they appear in the "1. Service" dropdown.
- [x] 2. Update `front end/staff.html` — replace the deposit number input with a range slider (100–1,000,000 NGN) plus a "Require a deposit" toggle for the add-service form.

## Follow-up (manual)
- [ ] Run `006_appointment_services.sql` against the database (e.g. phpMyAdmin or `mysql -u USER -p DBNAME < 006_appointment_services.sql`).

---

# SMS / WhatsApp Provider Implementation — TODO

## Steps
- [x] 1. Expand `backend/src/config.php` — add Termii, Twilio, and WhatsApp Business Cloud API credentials + click-to-chat link config.
- [x] 2. Rewrite `backend/src/notifier.php` — real Termii + Twilio SMS dispatch, real WhatsApp Business Cloud API sender, prefer click-to-chat link.
- [x] 3. Create `backend/.env.example` — document all new provider keys.
- [x] 4. Update `backend/README.md` — document provider setup and how to disable (leave blank).
- [x] 5. Update `front end/index.html` — replace hardcoded `wa.me/08036893332` links with the click-to-chat link.
- [x] 6. Update `front end/videos.html` — replace hardcoded `wa.me/08036893332` links with the click-to-chat link.
- [x] 7. Update `front end/appointment.html` — replace hardcoded `wa.me/2348036893332` link with the click-to-chat link.
- [x] 8. Update all WhatsApp links to `https://wa.me/qr/EMC2SHBW54CAC1` across `front end/index.html` and `front end/videos.html` (replaced the previous `https://wa.me/message/VEALYDXXF4PDF1`).

## Implementation plan (approved)
1. Create `backend/.env.example` with all provider keys documented and grouped.
2. Update `backend/README.md` to reference the new `.env.example` and clarify provider setup/disable behavior.
3. Update `front end/index.html`:
   - Footer WhatsApp link (`wa.me/08036893332`) → click-to-chat link.
   - Mindwave assistant WhatsApp base/number → click-to-chat link.
4. Update `front end/videos.html`:
   - Floating WhatsApp button (`wa.me/08036893332`) → click-to-chat link.
   - Footer WhatsApp link (`wa.me/08036893332`) → click-to-chat link.
5. Update `front end/appointment.html`:
   - Sidebar "Contact the clinic on WhatsApp" link (`wa.me/2348036893332`) → click-to-chat link.

